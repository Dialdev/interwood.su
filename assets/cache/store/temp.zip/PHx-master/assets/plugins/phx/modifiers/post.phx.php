<?php

// Returns the POST parameter which has been posted
// It takes the paramater name as an argument
// [*phx:post=`paramname`*] 

return $_POST[$options];

?>